Place R files here so that they are visible in both the host and the VM.

To make RStudio point to this directory by default, set the option in
  Tools -> Global Options -> Default working directory

